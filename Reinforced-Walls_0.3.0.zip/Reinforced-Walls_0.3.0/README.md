Reinforced Walls 0.3.0 by Michael Cowgill (ChurchOrganist)

This is my first attempt at a [Factorio](http://www.factorio.com/) mod. 

It adds some upgraded wall types to your base defence system.

This has been tested in sandbox mode and can be researched built and placed.

Currently there are 2 types which you can research.

1. Reinforced Wall with double hitpoints.
2. Acid Resist Wall which adds resistance to acid and enhanced physical resistance.

It is licensed under the MIT license, available in this package in the file  LICENSE.md.

For more information on this licence please visit: http://opensource.org/licenses/mit-license.html
