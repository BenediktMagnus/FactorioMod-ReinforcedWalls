data:extend({
 {
    type = "item",
    name = "reinforced-wall",
    icon = "__Reinforced-Walls__/graphics/icons/reinforced-wall.png",
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
    order = "a[reinforced-wall]-a[reinforced-wall]",
    place_result = "reinforced-wall",
    stack_size = 100
  }
  
})