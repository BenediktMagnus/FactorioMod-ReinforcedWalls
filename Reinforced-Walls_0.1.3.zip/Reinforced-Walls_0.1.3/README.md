Reinforced Walls 0.1.3 by Michael Cowgill (ChurchOrganist)

This is my first attempt at a [Factorio](http://www.factorio.com/) mod. It adds an upgraded wall with double hitpoints to your base defence system.

This is now tested in sandbox mode and can be researched built and placed

It is licensed under the MIT license, available in this package in the file  LICENSE.md.

For more information on this licence please visit: http://opensource.org/licenses/mit-license.html
