data:extend({
 {
    type = "item",
    name = "reinforced-wall",
    icon = "__base__/graphics/icons/stone-wall.png",
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
    order = "a[reinforced-wall]-a[reinforced-wall]",
    place_result = "reinforced-wall",
    stack_size = 100
  }
  
})